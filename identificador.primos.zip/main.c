#include<stdio.h>

int main() {
    int n, i, eh_primo;
    
    
    
    printf("digite um numero inteiro positivo:");
    scanf("%d", &n);
    
    if(n != 1) {
        for(i = 2, eh_primo = 1; (i <= n/2) && (eh_primo); i++){
            if((n % i) == 0) {
                eh_primo = 0;
            }

        }    
    } else {
        eh_primo = 0;
    }
        
    if(eh_primo) {
      printf("%d é primo.", n);
    }else {
      printf("%d não é primo.", n);
    }
     return 0;   
}
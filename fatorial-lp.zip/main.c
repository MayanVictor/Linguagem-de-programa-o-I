
#include <stdio.h>

int main()
{
    int n, i, k = 1;
    printf("digite um número: ");
    scanf("%d", &n);
    
    for(i = n; i > 1; i--) {
        k *= i;
    }
    printf("o fatorial de %d é igual a %d", n, k);

    return 0;
}


#include <stdio.h>

int main()
{
    int C, F, opcao;
    printf("digite '1' se quiser converter de Celsius para Fahrenheit e '2' para fahrenheit para celsius: " );
    scanf("%d", &opcao);
    
    if(opcao == 1) {
        printf("digite uma temperatura em celsius: ");
        scanf("%d", &C);
        F = (9 * (C / 5)) + 32;
        printf("a temperatura %d Celsius é igual %d Fahrenheit", C, F);
    }else{
        printf("digite uma temperatura em Fahrenheit: ");
        scanf("%d", &F);
        C = (5*F - 160) / 9;
        printf("a temperatura %d Fahrenheit é igual %d Celsius", F, C);
    }
    
    return 0;
}


#include <stdio.h>

int main()
{
    int vetor[5], i = 0, k;
    do{
        printf("digite um número: ");
        scanf("%d", &vetor[i]);
        i++;
        
    } while(i <= 4);
    k = vetor[0] + vetor[1] + vetor[2] + vetor[3] + vetor[4];
    printf("a soma da %d", k);

    return 0;
}


#include <stdio.h>
#include <string.h>
int main()
{
    char texto[100];
    
    printf("escreva uma frase: ");
    scanf("%s", texto);
    
    int tamanho = strlen(texto);
    
    printf("seu texto possui %d characteres", tamanho);
    
    return 0;
}

